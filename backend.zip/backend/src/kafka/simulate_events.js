require("dotenv").config();
const { producer } = require("./producer");

const topic = "inventory-events";



module.exports = {};
